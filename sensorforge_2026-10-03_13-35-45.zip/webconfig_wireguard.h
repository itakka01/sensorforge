#pragma once

#include <Arduino.h>

class WebServer;

String webconfigWireGuardSettingsHtml(const String &notice);

bool webconfigWireGuardSaveRequest(
    WebServer &server,
    bool writeToSd,
    String &error
);
