#pragma once

// ============================================================================
// SensorForge release identity
// ============================================================================
//
// This is the human/project release number for the complete source tree.
// It is intentionally separate from:
//   - SENSORFORGE_CORE_VERSION in branding.h (product/core compatibility)
//   - __DATE__ / __TIME__ (individual compiler build timestamp)
//   - API protocol versions (sync_api.cpp)
//
// Release workflow:
//   1. Increment SENSORFORGE_RELEASE_NUMBER / SENSORFORGE_RELEASE_TAG.
//   2. Update SENSORFORGE_RELEASE_DATE and SENSORFORGE_RELEASE_SUMMARY.
//   3. Add the release to CHANGELOG.md.
//   4. Commit the complete project to Git.
//   5. Create a Git tag with exactly SENSORFORGE_RELEASE_TAG (for example v35).
//
// The same release tag is written to the firmware boot log and shown in
// WebConfig, so a running device can be mapped back to the exact Git tag.

#define SENSORFORGE_RELEASE_NUMBER 86
#define SENSORFORGE_RELEASE_TAG "v86"
#define SENSORFORGE_RELEASE_DATE "2026-10-01"
#define SENSORFORGE_RELEASE_SUMMARY \
    "Role-based stream access, protected RTSP/HTTP-MJPEG, Home Assistant guidance and post-v85 WiFi persistence fixes."

// Current source-tree stage. v86 is the official release checkpoint.
#define SENSORFORGE_WORKTREE_STAGE "v86-release"
#define SENSORFORGE_WORKTREE_DATE "2026-10-01"
#define SENSORFORGE_WORKTREE_SUMMARY \
    "Official v86 release: role-based stream access, protected streams, Home Assistant guidance and WiFi persistence fixes."
