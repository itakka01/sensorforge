# SensorForge Changelog

Current development worktree: **v87-beta49**  
Last stable official release: **v86**  
Core branding version: **7.1.0**

This changelog is intentionally concise. Detailed intermediate experiments and
superseded implementation notes belong in Git history and the project re-entry
document, not in an ever-growing release file.



## v87-beta49 — 2026-10-08

- Compile-only fix for the Beta 48 Cluster restart page. `webconfig.cpp` now includes `cluster.h`, which declares `clusterEffectiveId()`.
- No runtime, Cluster protocol, WiFi, storage, recording, or configuration behavior changed.

## v87-beta48 — 2026-10-08

- Fixed first-use Known-Cluster profile lookup on new boards: the NVS namespace does not exist until the first profile is written, and opening it read-only was previously reported as `cluster profile storage unavailable`. Explicit join/save lookup now opens the profile namespace read-write so an empty namespace is initialized safely; a truly unavailable NVS backend still remains an error.
- Cluster settings now follow the same boot-owned apply model as WiFi settings. After a successful persistent cluster save, WebConfig shows a dedicated restart notice and schedules a controlled reboot. This guarantees the newly saved membership/ID/password/policy is applied by a fresh `clusterNetworkStart()` instead of leaving `restart_required` with an inactive/old runtime.
- Passive discovery behavior itself is unchanged: only active cluster members emit public `SFD1` discovery announcements every heartbeat, and a disabled device listens only while `/cluster` is actively open. The UI now states that only active Beta-38-or-newer members are discoverable.
- No change to cluster authentication, election ordering, heartbeat/lease timing, resource announcements, WiFi ownership or recording/streaming paths.

## v87-beta47 — 2026-10-08

- Fixed a real no-SD boot crash observed after Beta 46: after the five expected SD mount retries, the ESP32-S3 entered config load/recovery and hit `Stack canary watchpoint triggered (loopTask)`, causing a reboot loop before WiFi could start.
- The SD failure itself is not treated as fatal. The crash source was excessive nested stack use in config parsing/default/recovery: `ConfigValues` has grown with Camera/Audio/WiFi/Cluster/etc. and several paths created large local instances or return-value temporaries on Arduino's loopTask stack.
- Reworked the config working-object lifetime without changing schema/semantics: defaults are filled into an existing object, validation/parsing/apply/factory-reset temporary `ConfigValues` objects are allocated with bounded temporary heap storage, and the boot load path no longer keeps large `ConfigValues` locals on the loopTask stack.
- This also makes Beta-45 orphaned `/config.tmp` recovery safer, because its validation no longer adds another large `ConfigValues` frame underneath the boot/config call chain.
- Config priority remains SD > internal LittleFS > firmware defaults. Missing SD remains a supported condition; WiFi, Cluster, recording policy and config contents are otherwise unchanged.

## v87-beta46 — 2026-10-08

- WiFi settings are now applied through a controlled reboot immediately after a successful, verified save. Previously the runtime config was updated while the old WiFi interface kept running; a later inactivity timeout could shut that old interface down without ever starting the newly configured STA/fallback path.
- After saving, WebConfig redirects to a dedicated restart/reconnect notice showing the new device name, selected network mode and fallback policy before the old connection disappears.
- The existing STA profile connection and hotspot fallback logic is unchanged; it is now deterministically re-entered by the reboot.
- No change to recording, cluster, storage, config persistence format or WiFi timeout semantics.

## v87-beta45 — 2026-10-08

- Fixed a concrete atomic-config recovery bug exposed by a fresh board without SD: if the very first internal save was interrupted after a complete `/config.tmp` had been written but before `/config.txt` existed, boot recovery previously deleted that temporary file and the device fell back to firmware defaults.
- `recoverAtomicFiles()` now reads and validates an orphaned `/config.tmp`; when valid and no older `/config.txt`/`/config.bak` exists, it reconstructs `/config.txt` from that candidate and only removes the temp file after the final path is verified. Invalid/incomplete temp files are still discarded.
- `atomicWriteText()` no longer treats a successful `rename()` alone as a committed save. The final `/config.txt` is reopened, compared byte-for-byte with the intended text and validated before the backup is discarded or success is returned.
- On a first-ever save, if the metadata rename cannot produce a verified final file, the same already-validated text is written directly to `/config.txt` and verified. Existing-config updates retain backup/rollback semantics.
- This change is inside the shared config persistence layer; WiFi semantics, SD priority, Cluster, recording and streaming behavior are unchanged.


## v87-beta44 — 2026-10-08

- WiFi WebConfig display-only fix: the shown `Hotspot-Name` now updates immediately while the user edits `Gerätename` / `hostname` at the top of the same page.
- The preview uses browser `textContent`; it does not save, restart, open or reconfigure WiFi. The actual hotspot name is still persisted only through the existing WiFi Save path and becomes active according to the existing network/reboot lifecycle.
- No config format, WiFi runtime, fallback, Cluster, recording, storage or persistence behavior was changed.


## v87-beta43 — 2026-10-08

- Hardened the internal LittleFS configuration store after a real no-SD first-run test showed that a saved internal config could disappear or become unavailable after reboot and WebConfig then fell back to firmware defaults.
- Removed destructive unconditional mount-failure recovery. SensorForge now retries a normal LittleFS mount and automatically formats only when the exact internal `spiffs` data partition is demonstrably blank/erased (fresh first-run case).
- If LittleFS mount fails while flash data is already present, SensorForge preserves that data and does **not** format the filesystem. Runtime falls back safely, allowing the existing WiFi recovery behavior to keep the device reachable where possible.
- Added exact internal-config diagnostics: `valid`, `missing`, `invalid`, `unavailable`, plus a detail string such as validation/decryption failure or mount-failure preservation. `/config` now shows this reason instead of the ambiguous `missing / invalid` text.
- Internal config writes still use the existing validated atomic write + SFSEC1 protection path. SD priority, WiFi configuration semantics, Cluster, recording and storage behavior are otherwise unchanged.
- This is a persistence hardening/diagnostic release; the reported fresh-board issue must be re-tested on real hardware before claiming the underlying LittleFS failure mode is fully closed.


## v87-beta42 — 2026-10-08

- Hardened WiFi provisioning after the Beta-40/41 first-run path. The dedicated WiFi save now rejects `hotspot_enabled=0` (infrastructure/STA mode) when no SSID profile is configured, instead of persisting a state that can never connect.
- Added a narrow boot-time recovery for historical/partially provisioned configs that already contain STA mode with zero configured SSIDs: SensorForge starts the normal local hotspot as a recovery path even if the stored fallback flag is `0`.
- This recovery does **not** override the explicit `Offline bleiben` choice when at least one actual infrastructure WiFi profile exists. If configured profiles exist but are unreachable and fallback is disabled, the established offline behavior remains authoritative.
- Successful STA connection, normal hotspot mode, WiFi timeout, schedule, Cluster networking and all recording/storage paths are unchanged.

## v87-beta41 — 2026-10-08

- Changed only the factory/default value of `hotspot_fallback_enabled` from `0` to `1`.
- When infrastructure WiFi is selected and no configured network is reachable, a factory/default configuration now falls back to the device hotspot instead of remaining offline.
- Existing persisted configs remain authoritative: a device that already stores `hotspot_fallback_enabled=0` stays on `0` until the user changes it.
- The normal hotspot/STA lifecycle, fallback implementation, WiFi timeout and Beta-40 first-run persistence path are otherwise unchanged.

## v87-beta40 — 2026-10-08

- Fixed first-run WiFi persistence on a freshly flashed board with no SD card and no existing internal `/config.txt`.
- `configSaveWifiSettings()` now uses the existing canonical `configBuildFactoryDefaultText()` output as the complete initial baseline only when neither SD nor LittleFS contains a persistent config, then patches the requested WiFi keys and passes the result through the unchanged validation, SFSEC1 secret-protection and `configSaveText()` path.
- The first successful save creates only the internal LittleFS `/config.txt`; it does not create an SD config. Existing SD > internal > defaults priority and later SD synchronization rules remain unchanged.
- Existing boards that already have a persistent config follow the exact previous patch path; no camera, recording, Cluster, WiFi runtime or SD behavior was otherwise changed.

## v87-beta39 — 2026-10-08

- Fixed an Arduino-ESP32 3.3.12 compile error in `cluster.cpp`: Arduino defines `HEX` as a macro in `Print.h`, which collided with the local hexadecimal lookup-table name used by `textToHex()`.
- Renamed only that local lookup table to `HEX_DIGITS`; Cluster protocol, configuration, networking, credentials, election and runtime behavior are unchanged from Beta 38.

## v87-beta38 — 2026-10-08

- Added `CLUSTER_ARCHITECTURE.md` as the detailed Beta-38 Cluster freeze/re-entry reference. It records current ownership rules, identities, ports, packet families, election/liveness/credential behavior, known limitations, hardware-test status and the intended future Time-Master/scheduled-capture continuation without changing firmware behavior.
- Added page-scoped passive Cluster discovery. While `/cluster` is actively open, a disabled device may temporarily join the Cluster multicast receive group, but it sends no SensorForge Cluster packet, does not join any Cluster and never starts/extends WiFi. The listener expires automatically after browser polling stops.
- Added public stable `cluster_id` (`cl-` + 128-bit hex) and `cluster_credential_epoch`. Existing Beta-37 configs without an ID receive a deterministic legacy ID derived from the existing Cluster name and persist it on the next Cluster save.
- Active Cluster members emit a tiny unauthenticated `SFD1` discovery announcement every normal 10 s heartbeat containing only Cluster ID/name, credential epoch, node ID, policy and release. It contains no password and grants no membership.
- `/cluster` now builds a dropdown from discovered Clusters plus previously known Clusters. Cluster ID/name can still be entered manually and a new ID is generated automatically when omitted for a new Cluster.
- Added a board-local known-Cluster cache (up to six entries) in NVS. Passwords are encrypted with the existing hardware-bound SFSEC1 mechanism and are never returned to the browser/status JSON. Successfully authenticated membership refreshes the matching cached credential; a freshly created local Cluster is cached immediately.
- If discovery reports a credential epoch different from the saved profile, the saved password is treated as stale and is not reused automatically. The user must enter the new password.
- A local password edit for the same Cluster ID is rejected while authenticated remote peers are currently attached. This prevents accidentally splitting a healthy multi-node Cluster. Isolated recovery/rejoin remains possible and advances the credential epoch when necessary.
- Defined the future password-rotation rule: Cluster-wide credential rotation is a Coordinator transaction (prepare/ACK/commit) and is not partially implemented in Beta 38. Offline nodes that miss a future rotation will see a newer credential epoch and must be re-credentialed.
- Same Cluster ID with incompatible credentials never participates in the same election. The public discovery view can expose the shared ID while authenticated membership remains partitioned, avoiding an automatic or ambiguous password winner.
- Existing signed `SFC1`/lease/resource/coordinator packet layouts remain structurally compatible, but Beta 38 intentionally changes the HMAC/tag trust domain to `cluster_id + password` (`SensorForgeClusterKeyV2`). All members of one Cluster must therefore be updated to Beta 38 together; mixed Beta-37/Beta-38 Cluster membership is not supported. Upgraded Beta-37 configs derive the same deterministic legacy `cluster_id` from their existing Cluster name, so Beta-38 nodes converge after the joint update. mDNS metadata advances to protocol version 4 and adds public Cluster ID/credential-epoch fields.

## v87-beta37 — 2026-10-08

- Added automatic Cluster Coordinator selection without changing WiFi ownership or any recording/streaming lifecycle.
- Added `cluster_coordinator_policy=auto|preferred|node`; default is `auto`, so older configs remain valid without migration. `node` can never become Coordinator; `preferred` outranks `auto`; ties are deterministic by stable `integration_id`.
- The selected Coordinator receives a runtime epoch/generation. Nodes track Coordinator ID + epoch as the future authorization context for coordinated commands; Beta 37 does not yet execute remote commands.
- Added a dedicated authenticated unicast coordination socket on UDP 39428. Every non-Coordinator sends a signed heartbeat every 10 s to the current Coordinator and receives a signed ACK.
- Direct Node→Coordinator heartbeats refresh the Coordinator's peer liveness, so the central view remains reliable even if individual multicast presence packets are missed. Broadcast/multicast remains best-effort discovery/event transport.
- Coordinator election changes only when authenticated peer state changes through LEAVE/lease expiry or a higher-ranked candidate appears; a single missed broadcast does not trigger failover.
- Expanded `/cluster` to show configured policy, actual runtime role, selected Coordinator/epoch and direct heartbeat/ACK age per device.
- mDNS `_sfcluster._udp` remains on the existing central responder; protocol metadata is now version 3 and advertises the separate coordination port.
- Cluster remains disabled by default and still never starts, prolongs or keeps WiFi alive. Time Master/laser synchronization, production sessions and remote snapshot/recording commands remain future stages.

## v87-beta36 — 2026-10-08

- Extended the optional local cluster without changing SensorForge WiFi ownership.
- Presence remains every 10 s; peer liveness now uses a 60 s lease rather than a fixed 35 s timeout.
- Added a small authenticated metadata packet carrying `lease_sec` and an approximate `wifi_remaining_sec`.
- Added a signed best-effort `LEAVE` packet before orderly WiFi shutdown so peers can remove the node immediately; unexpected power/radio loss still falls back to lease expiry.
- Cluster code still never starts, prolongs or keeps WiFi alive. With `cluster_enabled=0`, no cluster socket, mDNS service, heartbeats, HMAC work or resource traffic is started.
- Expanded `/cluster` into a whole-cluster overview showing local/remote nodes, release, operating state, lease remainder, approximate WiFi lifetime and last-seen age.
- Added a generic HMAC-authenticated resource-announcement foundation (`SFR1`) with source node, resource ID/type, UTC microsecond timestamp, size, TTL and compact locator metadata.
- Resource payload bytes are deliberately not multicast. Automatic peer download is not yet wired to storage/API; that will be a separate safety-reviewed step based on the existing concrete file-serving path.
- Existing Beta-34/35 `SFC1` presence packets remain wire-compatible; the new lease metadata is additive.

## v87-beta35 — 2026-10-08

- Fixed a WiFi schedule UI edge case that could submit duplicate start times.
- Newly added schedule rows now choose the next unused 15-minute start slot instead of always defaulting to `12:00`.
- Duplicate start times are detected locally in WebConfig and blocked with a clear browser validation message before the request reaches the config parser.
- The persistent schedule format, runtime scheduler and server-side validation remain unchanged.

## v87-beta34 — 2026-10-08

- Added an optional local SensorForge cluster foundation over the existing WiFi lifecycle; disabled by default for backward compatibility.
- Centralized the existing stable random `integration_id` in `device_identity.cpp/.h` so API and cluster use exactly the same NVS identity.
- Added `_sfcluster._udp` DNS-SD advertisement to the existing central mDNS responder without creating a second mDNS lifecycle.
- Added bounded authenticated UDP multicast presence/status (10 s heartbeat, 35 s peer timeout, max. 16 volatile peers) using HMAC-SHA256.
- Cluster password is persisted through the existing SFSEC1 secret-protection path and is never advertised or returned by status JSON.
- Added dedicated `cluster.cpp/.h` and `webconfig_cluster.cpp/.h`; `webconfig.cpp` only receives navigation/registration hooks.
- Added `/cluster` read-only peer status UI and persisted cluster membership settings. Changes take effect on the next normal WiFi/device restart; no forced reboot is triggered by the page.
- Time validity/epoch is status-only groundwork. Beta 34 does not implement clock correction, remote commands or synchronized multi-camera recording.
- Strengthened the documented development rules: work only from current source, never guess code, preserve existing functionality, safety first, delta ZIPs only, and keep new WebConfig functionality modular.

## v87-beta33 — 2026-10-08

- Extracted the complete Transport Security WebConfig page and its handlers from
  `webconfig.cpp` into `webconfig_transport.cpp/.h`.
- Kept URLs, config keys, measurement flow, recording-pause handling, activation,
  cancellation and reboot semantics unchanged.
- Structural cleanup only; no intended product behavior change.

## v87-beta32 — 2026-10-08

- Simplified Transport Security time controls.
- Maximum transport duration is edited as minutes / hours / days and remains
  stored internally in seconds.
- Transport check interval is edited as minutes / hours; default is now 10 min.
- Confirmation seconds field uses the same compact width as other time controls.
- Removed redundant human-readable total-time echoes from the form.
- Expanded maximum check interval to 24 h and allowed transport duration from
  1 minute up to the existing 7-day maximum.

## v87-beta31 — 2026-10-08

- Gave Transport Security the same floating Save control pattern as other
  WebConfig settings.
- Changed WiFi timeout editing from seconds to minutes while keeping
  `wifi_timeout_sec` as the canonical internal/config representation.
- Kept compatibility with old seconds-based POSTs.
- Prevented unusually bright black-reference measurements from being copied into
  the suggested Transport Security threshold.

## v87-beta30 — 2026-10-07

- Added the SF2 board-bound activation format with a signed issuer key ID.
- Added a license public-key ring with issuer capabilities.
- Firmware now validates both ECDSA signature and issuer authorization, so a
  server key restricted to EVALUATION cannot issue FULL/SERVICE licenses.
- Added tooling for future separated TRIAL, FULL authority and RECOVERY keypairs.
- Production model: online server holds only the restricted trial signer; FULL /
  SERVICE authority and RECOVERY keys remain offline or later non-exportable in
  HSM/KMS.
- Firmware-signing and license-signing trust domains remain completely separate.
- Legacy SF1 remains accepted only for the current beta transition; production
  keyring generation disables it by default.

## v87-beta29 — 2026-10-06

- Split automatic trial media budgets into independent limits:
  - 20 h accumulated recording time
  - 100 h accumulated active streaming time
- Trial also retains the 14-day active/trusted-calendar limit.

## v87-beta28 — 2026-10-06

- Made TRIAL the automatic factory/default product mode; no activation is needed
  to evaluate the complete product.
- After trial exhaustion, devices fall back to DEMO.
- DEMO policy:
  - 10 recording starts per day
  - 1 h recording per day
  - 1 h active streaming per day
  - radar configuration/calibration remains available
  - local management/diagnostic API remains available
- Valid FULL/SERVICE licenses always override trial/demo accounting.
- Licensing limits remain centralized in `license_policy.cpp`.

## v87-beta27 — 2026-10-06

- Added accumulated active streaming usage accounting.
- Streaming time counts wall-clock time while at least one real RTSP or
  HTTP-MJPEG client is active; simultaneous viewers do not multiply usage.
- Added coarse low-wear persistence and live `STRM` UI telemetry.

## v87-beta26 — 2026-10-06

- Added accumulated system-uptime display and total filming-time display.
- Added product-mode badge to the main WebConfig screen.
- Kept uptime accounting deliberately approximate and low-wear across
  deep-sleep/reboot cycles.
- Added migration from the Beta-25 counter format.

## v87-beta25 — 2026-10-06

- Added the first persistent commercial-usage accounting layer.
- Tracks total recording count, recorded seconds, interrupted recordings and last
  trusted time anchor.
- Uses redundant CRC-protected NVS slots for robustness.
- Avoids writes at recording start and in the frame path; segment rotation is not
  counted as a new recording event.
- Initial release was measurement-only and intentionally fail-open.

## v87-beta24 — 2026-10-03

- Moved the user-facing VPN/WireGuard status into WiFi settings.
- Removed the standalone WireGuard configuration/navigation page from the active
  product UI.
- Kept internal config/secret/API scaffolding for future continuation.
- Parked the runtime backend: current XIAO/Freenove builds link no legacy
  WireGuard-ESP32 dependency.
- Camera, RTSP, ONVIF, audio, recording, storage, WiFi runtime and firmware-update
  paths remained unchanged. Host API remains 1.22.

## v87 milestone summary — 2026-10-02 to 2026-10-03

The earlier v87 betas established the major foundations that remain in the
current source tree:

- **Beta 1–2:** feature-freeze checkpoint and additive `/api/v1` expansion to
  host protocol 1.20+ / Integration profile 1.1.
- **Beta 3–4:** signed `.sfw` firmware update format and consolidated firmware
  signing/key workflow.
- **Beta 5–7:** recovery-hotspot consistency and centralized browser CSRF
  protection.
- **Beta 8:** documented local/trusted-network management security model.
- **Beta 9–18:** ONVIF discovery/authentication/interoperability work, culminating
  in field-qualified Discovery + Device/Media + Snapshot + RTSP/JPEG and later
  read-only Imaging/network extensions. No official ONVIF certification claim.
- **Beta 19–24:** WireGuard architecture experiment and cleanup; runtime backend
  ultimately parked because the legacy Arduino backend is incompatible with the
  current ESP-NETIF/Arduino-ESP32 reference stack.

Superseded per-beta debugging details are intentionally no longer duplicated here;
Git history retains them.

## v86 — 2026-10-01 — OFFICIAL

- Last stable official release before the v87 beta line.
- Consolidated role-aware WebConfig access, streaming-user accounts and media
  permissions.
- Added authentication for RTSP and direct HTTP-MJPEG when web access protection
  is enabled.
- Includes Home Assistant/network fixes and the previously stabilized camera,
  recording, storage and integration functionality.

## v85 — 2026-10-01 — OFFICIAL

- Image-Motion WebConfig/live-analysis milestone.
- Streamer frame-analysis groundwork.

## v84 — 2026-09-30 — OFFICIAL

- Network-streamer milestone.
- Multi-WiFi and camera/preview workflow improvements.

## Historical releases

Older pre-v84 release details are intentionally omitted from this concise file.
Use the Git history/tags and retained specialist project documents when a specific
legacy regression must be reconstructed.
