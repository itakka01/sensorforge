#pragma once

#include <Arduino.h>

// Optional SensorForge WireGuard client integration.
// The firmware remains fully functional when the external WireGuard-ESP32
// Arduino library is not installed; in that case the backend reports
// unavailable and no VPN interface is created.

void wireguardSetup();
void wireguardService(bool allowBlockingStart);
void wireguardStop(const char *reason = nullptr);

bool wireguardBuildAvailable();
bool wireguardBoardCapable();
bool wireguardConfigured();
bool wireguardActive();
bool wireguardRuntimeConfigMatchesSaved();

const char *wireguardBackendName();
String wireguardStatusText();
String wireguardLastError();
String wireguardRuntimeAddress();
