#include "webconfig_wireguard.h"

#include "config.h"
#include "wireguard_manager.h"

#include <WebServer.h>

namespace {

String htmlEscape(const String &value)
{
    String out;
    out.reserve(value.length() + 16);
    for (size_t i = 0; i < value.length(); ++i) {
        switch (value[i]) {
            case '&': out += F("&amp;"); break;
            case '<': out += F("&lt;"); break;
            case '>': out += F("&gt;"); break;
            case '"': out += F("&quot;"); break;
            case '\'': out += F("&#39;"); break;
            default: out += value[i]; break;
        }
    }
    return out;
}

String yesNo(bool value, bool english)
{
    if (english)
        return value ? "YES" : "NO";
    return value ? "JA" : "NEIN";
}

} // namespace

String webconfigWireGuardSettingsHtml(const String &notice)
{
    const bool english = cfg_web_language == "en";
    String html;

    const String title = "WireGuard VPN";
    const String intro = english
        ? "Optional encrypted client tunnel for remote SensorForge access."
        : "Optionaler verschlüsselter Client-Tunnel für entfernten SensorForge-Zugriff.";
    const String statusHeading = english ? "Status" : "Status";
    const String boardLabel = english ? "Board" : "Board";
    const String backendLabel = english ? "Backend" : "Backend";
    const String runtimeLabel = english ? "Runtime" : "Laufzeit";
    const String addressLabel = english ? "VPN address" : "VPN-Adresse";
    const String activeLabel = english ? "Tunnel active" : "Tunnel aktiv";
    const String lastHintLabel = english ? "Last hint" : "Letzter Hinweis";
    const String rebootText = english
        ? "Reboot required: the saved values differ from the configuration captured at boot."
        : "Neustart erforderlich: Die gespeicherten Werte unterscheiden sich von der aktuell laufenden Boot-Konfiguration.";

    html +=
        "<div class='page-title'><div><h2>" + title + "</h2><p>" + intro +
        "</p></div></div>";

    if (notice == "saved") {
        html +=
            "<div class='notice success'>" +
            String(english
                ? "WireGuard settings saved. A reboot is required before the new tunnel configuration is used."
                : "WireGuard-Einstellungen gespeichert. Die neue Tunnelkonfiguration wird erst nach einem Neustart verwendet.") +
            "</div>";
    }

    html += "<section class='settings-section'><h3>" + statusHeading + "</h3>";
    html += "<div class='kv-grid'>";
    html += "<div>" + boardLabel + "</div><div>" +
            String(wireguardBoardCapable() ? (english ? "capable" : "freigegeben") : (english ? "not capable" : "nicht freigegeben")) +
            "</div>";
    html += "<div>" + backendLabel + "</div><div><code>" + htmlEscape(String(wireguardBackendName())) + "</code>" +
            String(wireguardBuildAvailable() ? "" : (english ? " <strong>(not installed)</strong>" : " <strong>(nicht installiert)</strong>")) + "</div>";
    html += "<div>" + runtimeLabel + "</div><div>" + htmlEscape(wireguardStatusText()) + "</div>";
    html += "<div>" + addressLabel + "</div><div><code>" + htmlEscape(wireguardRuntimeAddress()) + "</code></div>";
    html += "<div>" + activeLabel + "</div><div>" + yesNo(wireguardActive(), english) + "</div>";
    html += "</div>";

    if (wireguardLastError().length()) {
        html += "<p class='muted'><strong>" + lastHintLabel + ":</strong> " + htmlEscape(wireguardLastError()) + "</p>";
    }

    if (!wireguardRuntimeConfigMatchesSaved()) {
        html += "<p><strong>" + rebootText + "</strong></p>";
    }

    if (!wireguardBuildAvailable()) {
        html +=
            "<p><strong>" + String(english ? "Backend missing:" : "Backend fehlt:") + "</strong> " +
            String(english
                ? "The Arduino build currently supports the optional WireGuard-ESP32 backend when that library is available. Without a backend SensorForge remains fully functional with VPN disabled."
                : "Der Arduino-Build unterstützt derzeit optional das WireGuard-ESP32-Backend, wenn diese Bibliothek verfügbar ist. Ohne Backend bleibt SensorForge bei deaktiviertem VPN vollständig lauffähig.") +
            "</p>";
    }
    html += "</section>";

    html +=
        "<section class='settings-section'><h3>" + String(english ? "Configuration" : "Konfiguration") + "</h3>"
        "<form method='POST' action='/wireguard_save'>"
        "<label class='check-row'><input type='checkbox' name='wireguard_enabled' value='1'" +
        String(cfg_wireguard_enabled ? " checked" : "") +
        "> <span><strong>" + String(english ? "Enable WireGuard" : "WireGuard aktivieren") + "</strong><br><span class='muted'>" +
        String(english
            ? "Default OFF. Requires infrastructure WiFi (STA); the local hotspot mode is intentionally not supported."
            : "Standardmäßig AUS. Funktioniert nur im Infrastruktur-WLAN (STA); der lokale Hotspot-Modus wird bewusst nicht unterstützt.") +
        "</span></span></label>"
        "<div class='form-grid'>"
        "<label>" + addressLabel + "</label><input name='wireguard_address' value='" + htmlEscape(cfg_wireguard_address) + "' placeholder='10.10.0.2'>"
        "<label>" + String(english ? "Peer endpoint" : "Peer Endpoint") + "</label><input name='wireguard_peer_endpoint' value='" + htmlEscape(cfg_wireguard_peer_endpoint) + "' placeholder='vpn.example.net'>"
        "<label>" + String(english ? "Peer port" : "Peer Port") + "</label><input type='number' min='1' max='65535' name='wireguard_peer_port' value='" + String(cfg_wireguard_peer_port) + "'>"
        "<label>" + String(english ? "Peer public key" : "Peer Public Key") + "</label><input name='wireguard_peer_public_key' value='" + htmlEscape(cfg_wireguard_peer_public_key) + "' autocomplete='off' placeholder='Base64 Public Key'>"
        "<label>" + String(english ? "Private key" : "Private Key") + "</label><input type='password' name='wireguard_private_key' value='' autocomplete='new-password' placeholder='" +
        String(cfg_wireguard_private_key.length()
            ? (english ? "configured — leave empty to keep" : "konfiguriert – leer lassen zum Beibehalten")
            : "Base64 Private Key") +
        "'>"
        "</div>"
        "<p class='muted'>" +
        String(english
            ? "The private key is stored as a SensorForge secret through the existing SFSEC1 path and is never returned by the Web UI or GET APIs."
            : "Der Private Key wird wie andere SensorForge-Secrets über den bestehenden SFSEC1-Pfad geschützt gespeichert und niemals in Weboberfläche oder GET-APIs zurückgegeben.") +
        "</p>"
        "<p class='muted'>" +
        String(english
            ? "The first product stage is deliberately conservative: one client tunnel / one peer. RTSP, ONVIF and snapshots through the VPN remain unqualified on ESP32-S3 until separate load and thermal tests are complete."
            : "Die erste Produktstufe ist bewusst konservativ: ein Client-Tunnel / ein Peer. RTSP, ONVIF und Snapshots über VPN gelten auf ESP32-S3 erst nach separatem Last-/Thermaltest als qualifiziert.") +
        "</p>"
        "<div class='save-bar'><button type='submit'>" + String(english ? "Save" : "Speichern") + "</button></div>"
        "</form></section>";

    return html;
}

bool webconfigWireGuardSaveRequest(
    WebServer &server,
    bool writeToSd,
    String &error
)
{
    const int enabled = server.hasArg("wireguard_enabled") ? 1 : 0;

    String address = server.arg("wireguard_address");
    address.trim();

    String endpoint = server.arg("wireguard_peer_endpoint");
    endpoint.trim();

    String publicKey = server.arg("wireguard_peer_public_key");
    publicKey.trim();

    String privateKey = server.arg("wireguard_private_key");
    privateKey.trim();
    if (!privateKey.length())
        privateKey = cfg_wireguard_private_key;

    long portValue = server.arg("wireguard_peer_port").toInt();

    ConfigSaveResult result = configSaveWireGuardSettings(
        enabled,
        address,
        privateKey,
        endpoint,
        publicKey,
        (int)portValue,
        writeToSd,
        error
    );

    return result == CONFIG_SAVE_BOTH || result == CONFIG_SAVE_INTERNAL_ONLY;
}
