#pragma once
#include <stdint.h>
namespace ClusterEspNowRadio {
// Diagnostic-only ESP-NOW timing. It never changes system or cluster time.
// Called from ordinary cluster loop, not from Wi-Fi callbacks.
void service(bool allowed, bool coordinator, uint32_t epoch,
             const char *coordinatorId, uint32_t localBootNonce);
void stop();
struct Diagnostics {
    uint32_t sent=0, received=0, authenticated=0, rejected=0, replay=0, dropped=0;
    uint32_t probesSent=0, probesAnswered=0, exchangesComplete=0, exchangeTimeouts=0;
    int64_t lastLocalRxUs=0;
    int64_t lastRemoteStampUs=0;
    double lastOffsetUs=0, lastRttUs=0;
    uint8_t channel=0;
    bool active=false;
    bool lastExchangeValid=false;
};
Diagnostics diagnostics();
}
