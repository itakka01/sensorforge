#include "cluster_espnow_radio.h"
#include "cluster_espnow_packets.h"
#include "cluster_espnow_twoway.h"
#include "cluster.h"
#include "board_config.h"
#include <Arduino.h>
#include <WiFi.h>
#include <esp_now.h>
#include <esp_wifi.h>
#include <esp_timer.h>
#include <freertos/FreeRTOS.h>
#include <freertos/portmacro.h>
#include <string.h>

#if defined(BOARD_HAS_ESP_NOW) && BOARD_HAS_ESP_NOW
namespace ClusterEspNowRadio {
namespace {
constexpr uint32_t kBroadcastEveryMs=10000;
constexpr uint32_t kProbeEveryMs=60000;
constexpr uint32_t kProbeGapMs=120;
constexpr uint32_t kExchangeTimeoutMs=1200;
constexpr uint8_t kSamplesPerSeries=16;
constexpr uint8_t kBroadcastMac[6]={255,255,255,255,255,255};
constexpr size_t kQueueSize=12;
struct Queued { uint8_t bytes[EspNowTimePackets::kPacketSize]; uint8_t mac[6]; int64_t rxUs; };
Queued queue[kQueueSize]={};
portMUX_TYPE queueMux=portMUX_INITIALIZER_UNLOCKED;
volatile uint8_t head=0,tail=0;
volatile uint32_t drops=0;
Diagnostics stats;
bool initialized=false, wasCoordinator=false;
uint8_t boundChannel=0;
uint32_t nextBroadcastMs=0,nextSeriesMs=0,nextProbeMs=0,txSequence=0,lastEpoch=0;
uint64_t lastTag=0;
EspNowTimePackets::ReplayWindow coordinatorReplay;
struct PeerReplay { bool used=false; uint8_t mac[6]={}; EspNowTimePackets::ReplayWindow replay; };
PeerReplay peerReplay[12];
struct Pending { bool active=false; uint32_t nonce=0; int64_t t1=0,t2=0; uint32_t startedMs=0; } pending;
ClusterEspNowTwoWay::Exchange exchanges[kSamplesPerSeries];
uint8_t seriesCount=0;
uint32_t nonceSeed=0;

uint64_t idTag(const char* id) {
    uint64_t x=14695981039346656037ULL;
    for(const unsigned char* p=reinterpret_cast<const unsigned char*>(id);p && *p;++p)
        x=(x^*p)*1099511628211ULL;
    return x ? x : 1;
}
void onReceive(const esp_now_recv_info_t* info,const uint8_t* data,int length) {
    if(!info||!info->src_addr||!data||length!=static_cast<int>(EspNowTimePackets::kPacketSize))return;
    const int64_t rx=esp_timer_get_time();
    portENTER_CRITICAL(&queueMux);
    uint8_t next=static_cast<uint8_t>((head+1)%kQueueSize);
    if(next==tail)++drops;
    else {
        memcpy(queue[head].bytes,data,EspNowTimePackets::kPacketSize);
        memcpy(queue[head].mac,info->src_addr,6);
        queue[head].rxUs=rx;head=next;
    }
    portEXIT_CRITICAL(&queueMux);
}
bool pop(Queued &v) {
    bool ok=false;
    portENTER_CRITICAL(&queueMux);
    if(tail!=head){v=queue[tail];tail=static_cast<uint8_t>((tail+1)%kQueueSize);ok=true;}
    portEXIT_CRITICAL(&queueMux);
    return ok;
}
void clearQueue(){portENTER_CRITICAL(&queueMux);head=tail=0;drops=0;portEXIT_CRITICAL(&queueMux);}
bool start(uint8_t channel) {
    if(esp_now_init()!=ESP_OK)return false;
    if(esp_now_register_recv_cb(onReceive)!=ESP_OK){esp_now_deinit();return false;}
    esp_now_peer_info_t peer={};
    memcpy(peer.peer_addr,kBroadcastMac,6);peer.channel=0;peer.ifidx=WIFI_IF_STA;
    if(esp_now_add_peer(&peer)!=ESP_OK){esp_now_deinit();return false;}
    initialized=true;boundChannel=channel;stats.active=true;stats.channel=channel;
    nextBroadcastMs=millis()+1000;nextSeriesMs=millis()+2000;
    return true;
}
uint32_t nextSequence(){++txSequence;if(!txSequence)++txSequence;return txSequence;}
bool sendFrame(EspNowTimePackets::Frame& f,const uint8_t mac[6]) {
    f.sequence=nextSequence();
    uint8_t b[EspNowTimePackets::kPacketSize];
    if(!EspNowTimePackets::encode(f,b,clusterEspNowTimeSign,nullptr))return false;
    if(esp_now_send(mac,b,sizeof(b))!=ESP_OK)return false;
    ++stats.sent;return true;
}
bool ensurePeer(const uint8_t mac[6]) {
    if(esp_now_is_peer_exist(mac))return true;
    esp_now_peer_info_t p={};memcpy(p.peer_addr,mac,6);p.channel=0;p.ifidx=WIFI_IF_STA;
    return esp_now_add_peer(&p)==ESP_OK;
}
bool acceptPeer(const uint8_t mac[6],const EspNowTimePackets::Frame &f) {
    PeerReplay* slot=nullptr;
    for(auto &p:peerReplay)if(p.used&&memcmp(p.mac,mac,6)==0){slot=&p;break;}
    if(!slot)for(auto &p:peerReplay)if(!p.used){slot=&p;p.used=true;memcpy(p.mac,mac,6);break;}
    if(!slot)return false;
    if(slot->replay.initialized &&
       (slot->replay.boot!=f.senderBoot||slot->replay.epoch!=f.epoch))
        slot->replay={}; // authenticated new boot; no time state transferred
    return EspNowTimePackets::acceptSequence(slot->replay,f);
}
void resetTiming(){pending={};seriesCount=0;nextProbeMs=0;for(auto &p:peerReplay)p={};coordinatorReplay={};}
void finishSample(int64_t t3,int64_t t4) {
    if(!pending.active||!pending.t2||t3<pending.t2||t4<pending.t1)return;
    if(seriesCount<kSamplesPerSeries)
       exchanges[seriesCount++]={pending.t1,pending.t2,t3,t4};
    pending={};++stats.exchangesComplete;
    if(seriesCount>=kSamplesPerSeries) {
        auto e=ClusterEspNowTwoWay::estimate(exchanges,seriesCount);
        stats.lastExchangeValid=e.valid;
        if(e.valid){stats.lastOffsetUs=e.offsetUs;stats.lastRttUs=e.medianRttUs;}
        seriesCount=0;nextSeriesMs=millis()+kProbeEveryMs;
    }
}
}
void stop() {
    if(initialized){esp_now_deinit();initialized=false;}
    boundChannel=0;lastEpoch=0;lastTag=0;stats.active=false;
    stats.lastExchangeValid=false;stats.lastOffsetUs=0;stats.lastRttUs=0;
    resetTiming();clearQueue();
}
Diagnostics diagnostics(){Diagnostics out=stats;portENTER_CRITICAL(&queueMux);out.dropped=drops;portEXIT_CRITICAL(&queueMux);return out;}
void service(bool allowed,bool coordinator,uint32_t epoch,const char* id,uint32_t localBootNonce) {
    if(!allowed||!epoch||!localBootNonce||!id||!*id||WiFi.status()!=WL_CONNECTED||
       WiFi.getMode()!=WIFI_MODE_STA){if(initialized)stop();return;}
    uint8_t channel=0;wifi_second_chan_t secondary=WIFI_SECOND_CHAN_NONE;
    if(esp_wifi_get_channel(&channel,&secondary)!=ESP_OK||!channel){if(initialized)stop();return;}
    uint64_t tag=idTag(id);
    if(initialized&&(boundChannel!=channel||lastEpoch!=epoch||lastTag!=tag||wasCoordinator!=coordinator))stop();
    if(!initialized&&!start(channel))return;
    wasCoordinator=coordinator;lastEpoch=epoch;lastTag=tag;
    Queued item;unsigned budget=0;
    while(budget++<5&&pop(item)) {
        ++stats.received;
        EspNowTimePackets::Frame f;
        if(!EspNowTimePackets::decode(item.bytes,sizeof(item.bytes),f,clusterEspNowTimeVerify,nullptr)||
           f.coordinatorTag!=tag||f.epoch!=epoch){++stats.rejected;continue;}
        if(coordinator) {
            if(f.type!=EspNowTimePackets::Type::Probe||!acceptPeer(item.mac,f)){
                ++stats.rejected;continue;
            }
            ++stats.authenticated;
            // Reply carries t2 (Coordinator RX), Final carries t3 (Coordinator TX).
            // Both are software timestamps. Nonce ties them to the same probe.
            if(!ensurePeer(item.mac)){++stats.rejected;continue;}
            EspNowTimePackets::Frame r;
            r.type=EspNowTimePackets::Type::Reply;r.epoch=epoch;r.coordinatorTag=tag;
            r.senderBoot=localBootNonce;r.nonce=f.nonce;r.timeUs=item.rxUs;
            if(!sendFrame(r,item.mac))continue;
            r.type=EspNowTimePackets::Type::Final;r.timeUs=esp_timer_get_time();
            if(sendFrame(r,item.mac))++stats.probesAnswered;
            continue;
        }
        if(f.type!=EspNowTimePackets::Type::Beacon&&
           f.type!=EspNowTimePackets::Type::Reply&&
           f.type!=EspNowTimePackets::Type::Final){++stats.rejected;continue;}
        if(!EspNowTimePackets::acceptSequence(coordinatorReplay,f)){++stats.replay;continue;}
        ++stats.authenticated;
        stats.lastLocalRxUs=item.rxUs;stats.lastRemoteStampUs=f.timeUs;
        if(f.type==EspNowTimePackets::Type::Reply&&pending.active&&f.nonce==pending.nonce)
            pending.t2=f.timeUs;
        if(f.type==EspNowTimePackets::Type::Final&&pending.active&&f.nonce==pending.nonce)
            finishSample(f.timeUs,item.rxUs);
    }
    uint32_t now=millis();
    if(coordinator){
        if(static_cast<int32_t>(now-nextBroadcastMs)>=0){
            nextBroadcastMs=now+kBroadcastEveryMs;
            EspNowTimePackets::Frame b;
            b.type=EspNowTimePackets::Type::Beacon;b.epoch=epoch;
            b.coordinatorTag=tag;b.senderBoot=localBootNonce;
            b.timeUs=esp_timer_get_time();b.nonce=static_cast<uint32_t>(b.timeUs);
            sendFrame(b,kBroadcastMac);
        }
        return;
    }
    if(pending.active&&static_cast<uint32_t>(now-pending.startedMs)>=kExchangeTimeoutMs){
        pending={};++stats.exchangeTimeouts;
    }
    if(seriesCount==0&&static_cast<int32_t>(now-nextSeriesMs)<0)return;
    if(pending.active||static_cast<int32_t>(now-nextProbeMs)<0)return;
    nextProbeMs=now+kProbeGapMs;
    if(!nonceSeed)nonceSeed=static_cast<uint32_t>(esp_timer_get_time())^localBootNonce;
    nonceSeed=nonceSeed*1664525u+1013904223u;
    if(!nonceSeed)++nonceSeed;
    EspNowTimePackets::Frame p;
    p.type=EspNowTimePackets::Type::Probe;p.epoch=epoch;p.coordinatorTag=tag;
    p.senderBoot=localBootNonce;p.timeUs=esp_timer_get_time();p.nonce=nonceSeed;
    if(sendFrame(p,kBroadcastMac)) {
        pending.active=true;pending.nonce=p.nonce;pending.t1=p.timeUs;
        pending.startedMs=now;++stats.probesSent;
    }
    // Clock steering intentionally omitted until actual Wi-Fi/ESP-NOW hardware validation.
}
}
#else
namespace ClusterEspNowRadio {
void service(bool,bool,uint32_t,const char*,uint32_t){}
void stop(){}
Diagnostics diagnostics(){return {};}
}
#endif
